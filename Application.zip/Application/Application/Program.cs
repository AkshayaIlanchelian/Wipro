﻿using Application.Model;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Application
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"D:\ApplicationFile.txt";

            List<UserModel> result = new List<UserModel>();
            result.Add(new UserModel { UserId = 1, FirstName = "Akshaya", LastName = "Ilanchelian", Age = 24, Role = Role.Manager | Role.Admin, Gender = Gender.Female });
            result.Add(new UserModel { UserId = 2, FirstName = "Karthik", LastName = "Raja", Age = 21, Role = Role.Admin | Role.Employee, Gender = Gender.Male });
            result.Add(new UserModel { UserId = 3, FirstName = "Raxana", LastName = "Vignesh", Age = 22, Role = Role.Employee |Role.Admin, Gender = Gender.Female });
            result.Add(new UserModel { UserId = 4, FirstName = "Puja", LastName = "Sivakumar", Age = 33, Role = Role.Manager | Role.Admin, Gender = Gender.Female });
            result.Add(new UserModel { UserId = 5, FirstName = "Joseph", LastName = "Morgan", Age = 41, Role = Role.Employee, Gender = Gender.Male });
            result.Add(new UserModel { UserId = 6, FirstName = "Jotsna", LastName = "Kumar", Age = 29, Role = Role.Manager | Role.Employee | Role.Admin, Gender = Gender.Female });
            result.Add(new UserModel { UserId = 7, FirstName = "Jothi", LastName = "Kavitha", Age = 36, Role = Role.Employee | Role.Manager, Gender = Gender.Male });
            result.Add(new UserModel { UserId = 8, FirstName = "Josephine", LastName = "Marcus", Age = 21, Role = Role.Manager | Role.Admin, Gender = Gender.Female });
            var obj = new Program();
            using (var sw = File.CreateText(path))
            {
                List<UserModel> womenYoungerThan25 = obj.GetWomenYoungerThan25(result);
                var headingText = "Women younger than 25 is/are \n";
                sw.WriteLine(headingText);

                if (womenYoungerThan25.Count > 0)
                {
                    foreach (var i in womenYoungerThan25)
                    {
                        var output = i.FirstName + " " + i.LastName + "\n";
                        sw.WriteLine(output);
                    }
                }
                else
                {
                    sw.WriteLine("NIl");
                }
                sw.WriteLine("--------------------------------------------------------------------------\n");

                UserModel GetYoungestMan = obj.GetYoungestMan(result);
                headingText = "The youngest man is\n";
                sw.WriteLine(headingText);

                if (GetYoungestMan != null)
                {
                    var res = GetYoungestMan.FirstName + " " + GetYoungestMan.LastName + "\n";
                    sw.WriteLine(res);
                }
                else
                {
                    sw.WriteLine("NIL");
                }
                sw.WriteLine("--------------------------------------------------------------------------\n");

                List<UserModel> menOlderThan40 = obj.GetMenOlderThan40(result);
                var text = "Men older than 40 is/are \n";
                sw.WriteLine(text);

                if (menOlderThan40.Count > 0)
                {
                    foreach (var i in menOlderThan40)
                    {
                        var output = i.FirstName + " " + i.LastName + "\n";
                        sw.WriteLine(output);
                    }
                }
                else
                {
                    sw.WriteLine("NIL");
                }
                sw.WriteLine("--------------------------------------------------------------------------\n");

                List<UserModel> managersFirstNameWithJo = obj.GetManagersFirstNameWithJo(result);
                headingText = "Women Managers whose name starts with 'jo' is/are \n";
                sw.WriteLine(headingText);

                if (managersFirstNameWithJo != null)
                {
                    foreach (var i in managersFirstNameWithJo)
                    {
                        var output = i.FirstName + " " + i.LastName + "\n";
                        sw.WriteLine(output);
                    }
                }
                else
                {
                    sw.WriteLine("NIL");
                }
                sw.WriteLine("--------------------------------------------------------------------------\n");

                List<UserModel> managerAndAdminInWomen = obj.GetManagerandAdminWomen(result);
                headingText = "Women who are Manager and Admin is/are \n";
                sw.WriteLine(headingText);

                if (managerAndAdminInWomen.Count > 0)
                {
                    foreach (var i in managerAndAdminInWomen)
                    {
                        var output = i.FirstName + " " + i.LastName + "\n";
                        sw.WriteLine(output);
                    }
                }
                else
                {
                    sw.WriteLine("NIL");
                }
                sw.WriteLine("--------------------------------------------------------------------------\n");

                foreach (var i in result)
                {
                    var output = i.FirstName + " " + i.LastName + " is " + i.Age + " years old. It is a " + i.Gender + ".He/She has the following roles " + i.Role + "\n";
                    sw.WriteLine(output);
                }
            }

        }
        private List<UserModel> GetWomenYoungerThan25(List<UserModel> result)
        {
            return result?.Where(x => x.Age < 25 && x.Gender == Gender.Female)?.ToList();
        }
        private UserModel GetYoungestMan(List<UserModel> result)
        {
            return result?.Where(x => x.Gender == Gender.Male).OrderBy(s => s.Age)?.FirstOrDefault();
        }
        private List<UserModel> GetMenOlderThan40(List<UserModel> result)
        {
            return result?.Where(x => x.Age > 40 && x.Gender == Gender.Male)?.ToList();
        }
        private List<UserModel> GetManagerandAdminWomen(List<UserModel> result)
        {
            return result?.Where(x => x.Gender == Gender.Female && (x.Role.HasFlag(Role.Manager) && x.Role.HasFlag(Role.Admin)))?.ToList();
        }
        private List<UserModel> GetManagersFirstNameWithJo(List<UserModel> result)
        {
            return result?.Where(x => x.FirstName.StartsWith("Jo"))?.ToList();
        }
    }
}
