﻿using Application.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Application
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = Path.Combine(Environment.CurrentDirectory, "ApplicationFile");           

            List<User> result = new List<User>();
            result.Add(new User { Id = 1, FirstName = "Akshaya", LastName = "Ilanchelian", Age = 24, Role = Role.Manager | Role.Admin, Gender = Gender.Female });
            result.Add(new User { Id = 2, FirstName = "Karthik", LastName = "Raja", Age = 21, Role = Role.Admin | Role.Employee, Gender = Gender.Male });
            result.Add(new User { Id = 3, FirstName = "Raxana", LastName = "Vignesh", Age = 22, Role = Role.Employee |Role.Admin, Gender = Gender.Female });
            result.Add(new User { Id = 4, FirstName = "Puja", LastName = "Sivakumar", Age = 33, Role = Role.Manager | Role.Admin, Gender = Gender.Female });
            result.Add(new User { Id = 5, FirstName = "Joseph", LastName = "Morgan", Age = 41, Role = Role.Employee, Gender = Gender.Male });
            result.Add(new User { Id = 6, FirstName = "Jotsna", LastName = "Kumar", Age = 29, Role = Role.Manager | Role.Employee | Role.Admin, Gender = Gender.Female });
            result.Add(new User { Id = 7, FirstName = "Jothi", LastName = "Kavitha", Age = 36, Role = Role.Employee | Role.Manager, Gender = Gender.Male });
            result.Add(new User { Id = 8, FirstName = "Josephine", LastName = "Marcus", Age = 21, Role = Role.Manager | Role.Admin, Gender = Gender.Female });
            
            using (StreamWriter sw = File.CreateText(path))
            {
                List<User> womenYoungerThan25 = GetWomenYoungerThan25(result);               
                sw.WriteLine("Women younger than 25 is/are \n");

                if (womenYoungerThan25.Count > 0)
                {
                    foreach (User i in womenYoungerThan25)
                    {
                        string output = i.FirstName + " " + i.LastName + "\n";
                        sw.WriteLine(output);
                    }
                }
                else
                {
                    sw.WriteLine("NIl");
                }

                sw.WriteLine("--------------------------------------------------------------------------\n");

                User getYoungestMan = GetYoungestMan(result);             
                sw.WriteLine("The youngest man is\n");

                if (getYoungestMan != null)
                {
                    string res = getYoungestMan.FirstName + " " + getYoungestMan.LastName + "\n";
                    sw.WriteLine(res);
                }
                else
                {
                    sw.WriteLine("NIL");
                }

                sw.WriteLine("--------------------------------------------------------------------------\n");

                List<User> menOlderThan40 = GetMenOlderThan40(result);
                
                sw.WriteLine("Men older than 40 is/are \n");

                if (menOlderThan40.Count > 0)
                {
                    foreach (User i in menOlderThan40)
                    {
                        string output = i.FirstName + " " + i.LastName + "\n";
                        sw.WriteLine(output);
                    }
                }
                else
                {
                    sw.WriteLine("NIL");
                }

                sw.WriteLine("--------------------------------------------------------------------------\n");

                List<User> managersFirstNameWithJo = GetManagersFirstNameWithJo(result);
               
                sw.WriteLine("Women Managers whose name starts with 'jo' is/are \n");

                if (managersFirstNameWithJo != null)
                {
                    foreach (User i in managersFirstNameWithJo)
                    {
                        string output = i.FirstName + " " + i.LastName + "\n";
                        sw.WriteLine(output);
                    }
                }
                else
                {
                    sw.WriteLine("NIL");
                }

                sw.WriteLine("--------------------------------------------------------------------------\n");

                List<User> managerAndAdminInWomen = GetManagerandAdminWomen(result);
                
                sw.WriteLine("Women who are Manager and Admin is/are \n");

                if (managerAndAdminInWomen.Count > 0)
                {
                    foreach (User i in managerAndAdminInWomen)
                    {
                        string output = i.FirstName + " " + i.LastName + "\n";
                        sw.WriteLine(output);
                    }
                }
                else
                {
                    sw.WriteLine("NIL");
                }

                sw.WriteLine("--------------------------------------------------------------------------\n");

                foreach (User i in result)
                {
                    string output = i.FirstName + " " + i.LastName + " is " + i.Age + " years old. It is a " + i.Gender + ".He/She has the following roles " + i.Role + "\n";
                    sw.WriteLine(output);
                }
            }
        }

        private static List<User> GetWomenYoungerThan25(List<User> result)
        {
            return result?.Where(x => x.Age < 25 && x.Gender == Gender.Female)?.ToList();
        }

        private static User GetYoungestMan(List<User> result)
        {
            return result?.Where(x => x.Gender == Gender.Male).OrderBy(s => s.Age)?.FirstOrDefault();
        }

        private static List<User> GetMenOlderThan40(List<User> result)
        {
            return result?.Where(x => x.Age > 40 && x.Gender == Gender.Male)?.ToList();
        }

        private static List<User> GetManagerandAdminWomen(List<User> result)
        {
            return result?.Where(x => x.Gender == Gender.Female && (x.Role.HasFlag(Role.Manager) && x.Role.HasFlag(Role.Admin)))?.ToList();
        }

        private static List<User> GetManagersFirstNameWithJo(List<User> result)
        {
            return result?.Where(x => x.FirstName.StartsWith("Jo"))?.ToList();
        }
    }
}
