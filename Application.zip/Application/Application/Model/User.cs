﻿using System;
using System.ComponentModel.DataAnnotations;


namespace Application.Model
{
    class User
    {
        [Required]
        public uint Id { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 3, ErrorMessage = " First Name must be between 3 and 50 character in length.")]
        public string FirstName { get; set; }
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Last Name must be between 3 and 50 character in length.")]
        public string LastName { get; set; }
        [Required]
        [Range(18, 56, ErrorMessage = "Age Must be between 18 to 56")]
        public uint Age { get; set; }
        [Required]
        public Role Role { get; set; }
        [Required]
        public Gender Gender { get; set; }
    }
    [Flags]
    enum Role
    {
        None =0,
        Manager =1,
        Employee =2,
        Admin=4
    }
    enum Gender
    {
        Male,
        Female
    }
}
